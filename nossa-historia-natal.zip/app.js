(() => {
  'use strict';
  const byId = (id) => document.getElementById(id);
  const all = (q) => [...document.querySelectorAll(q)];
  const DRAFT_KEY = 'nossa-historia-natal-demo-v1';
  const demo = {
    name1: 'Ana', name2: 'Lucas', how: 'Foi numa tarde de dezembro, em uma pequena livraria, que nossos caminhos se cruzaram. Você perguntou sobre o livro que eu segurava. A conversa durou horas, mas parecia que o mundo inteiro tinha parado.', date: '2023-12-18',
    letter: 'Se eu pudesse voltar àquele dezembro, encontraria você mais uma vez. Escolheria cada conversa, cada viagem improvisada e até os dias difíceis — porque todos eles nos trouxeram até aqui.\n\nQue a vida nos presenteie com muitos outros Natais lado a lado. Eu escolheria você em todas as histórias.',
    style: 'natal', plan: 'premium', wantsMusic: true,
    moments: [ { title: 'Nosso primeiro encontro', description: 'Uma tarde comum que se transformou em nossa lembrança favorita.' }, { title: 'A primeira viagem', description: 'Descobrimos que o mundo fica mais bonito quando é visto a dois.' }, { title: 'Nosso primeiro Natal', description: 'Luzes pela cidade e a certeza de que estar juntos é o maior presente.' } ]
  };
  const initial = { name1:'', name2:'', how:'', date:'', letter:'', style:'natal', plan:'essencial', wantsMusic:true, moments:[] };
  let state = { ...initial, moments: [] };
  let currentStep = 1;
  let photoObjects = [];
  let originScreen = 'landing';
  let music = null;
  let currentStoryIsDemo = false;
  let writeTimer = null;
  function safeParse(raw){ try { const parsed = JSON.parse(raw); if(!parsed || typeof parsed !== 'object') return null; return parsed; } catch { return null; } }
  let stored = null;
  try { stored = safeParse(localStorage.getItem(DRAFT_KEY)); } catch { stored = null; }
  if(stored){ state = { ...initial, ...stored, moments: Array.isArray(stored.moments) ? stored.moments.slice(0,30).map(m => ({title:String(m.title||'').slice(0,120), description:String(m.description||'').slice(0,600)})) : [] }; }
  function remember(){ clearTimeout(writeTimer); byId('draft-status').textContent='Salvando rascunho local...'; writeTimer=setTimeout(()=>{ try { localStorage.setItem(DRAFT_KEY,JSON.stringify(state)); byId('draft-status').textContent='✓ Textos salvos neste navegador'; } catch { byId('draft-status').textContent='Não foi possível salvar neste navegador'; } },350); }
  function go(screen){
    all('.view').forEach((v)=>{v.hidden=v.id!==screen+'-view';});
    document.body.dataset.screen=screen;
    all('[data-screen-only]').forEach(e=>e.style.display=screen==='landing'?'':'none');
    window.scrollTo({top:0,behavior:'instant'});
    if(screen!=='story')stopMusic();
    if(screen==='editor'){fillForm();setStep(currentStep);}
  }
  all('[data-go]').forEach((b)=>b.addEventListener('click',(e)=>{
    e.preventDefault();
    const plan=b.dataset.plan;
    if(plan){ state.plan=plan; remember(); }
    if(b.dataset.go==='demo'){ originScreen=document.body.dataset.screen; currentStoryIsDemo=true; prepareStory(demo); go('story'); }
    else { go(b.dataset.go); }
  }));
  function fillForm(){
    ['name1','name2','how','date','letter'].forEach(key=>byId(key).value=state[key]||'');
    byId('wants-music').checked=!!state.wantsMusic;
    all('.style-choice').forEach(e=>e.classList.toggle('selected',e.dataset.style===state.style));
    all('.plan-choice').forEach(e=>e.classList.toggle('selected',e.dataset.planChoice===state.plan));
    byId('mini-names').textContent=(state.name1.trim()||'Você')+' & '+(state.name2.trim()||'seu amor');
    renderMoments(); renderPhotos();renderSummary();
  }
  ['name1','name2','how','date','letter'].forEach(id=>byId(id).addEventListener('input',(e)=>{state[id]=e.target.value;if(id.startsWith('name'))byId('mini-names').textContent=(state.name1.trim()||'Você')+' & '+(state.name2.trim()||'seu amor');remember();}));
  byId('wants-music').addEventListener('change',(e)=>{state.wantsMusic=e.target.checked;remember();});
  all('.style-choice').forEach(b=>b.addEventListener('click',()=>{state.style=b.dataset.style;all('.style-choice').forEach(el=>el.classList.toggle('selected',el===b));remember();}));
  all('.plan-choice').forEach(b=>b.addEventListener('click',()=>{state.plan=b.dataset.planChoice;all('.plan-choice').forEach(el=>el.classList.toggle('selected',el===b));remember();renderSummary();}));
  function setStep(step){currentStep=step;all('.step-panel').forEach(e=>e.hidden=Number(e.dataset.panel)!==step);all('.step-button').forEach(e=>{e.classList.toggle('active',Number(e.dataset.step)===step);e.setAttribute('aria-current',Number(e.dataset.step)===step?'step':'false')});byId('prev-step').hidden=step===1;byId('next-step').hidden=step===4;if(step===4)renderSummary();}
  all('.step-button').forEach(b=>b.addEventListener('click',()=>setStep(Number(b.dataset.step))));
  byId('prev-step').addEventListener('click',()=>setStep(Math.max(1,currentStep-1)));
  byId('next-step').addEventListener('click',()=>setStep(Math.min(4,currentStep+1)));
  function renderMoments(){
    const root=byId('moments-list');root.replaceChildren();
    state.moments.forEach((moment,index)=>{
      const wrap=document.createElement('div');wrap.className='moment';
      const header=document.createElement('div');header.className='moment-head';
      const label=document.createElement('span');label.className='moment-number';label.textContent='Memória '+String(index+1).padStart(2,'0');header.append(label);
      const actions=document.createElement('div');actions.className='moment-actions';
      const opts=[['↑','Subir memória',index>0,()=>move(index,-1)],['↓','Descer memória',index<state.moments.length-1,()=>move(index,1)],['×','Remover memória',true,()=>{state.moments.splice(index,1);renderMoments();remember();}]];
      opts.forEach(([text,title,enabled,cb])=>{const b=document.createElement('button');b.type='button';b.textContent=text;b.title=title;b.setAttribute('aria-label',title);b.disabled=!enabled;b.addEventListener('click',cb);actions.append(b);});header.append(actions);wrap.append(header);
      [{field:'title',text:'Título do momento',max:120,place:'Ex.: Nossa primeira viagem'},{field:'description',text:'O que aconteceu?',max:600,place:'O que tornou esse momento especial?'}].forEach(spec=>{
        const l=document.createElement('label');l.textContent=spec.text;
        const inp=document.createElement(spec.field==='description'?'textarea':'input');
        inp.className='moment-input';inp.maxLength=spec.max;inp.placeholder=spec.place;inp.value=moment[spec.field]||'';
        inp.addEventListener('input',e=>{moment[spec.field]=e.target.value;remember();});l.append(inp);wrap.append(l);
      }); root.append(wrap);
    });
  }
  function move(index,delta){const target=index+delta;if(target<0||target>=state.moments.length)return;const [entry]=state.moments.splice(index,1);state.moments.splice(target,0,entry);renderMoments();remember();}
  byId('add-moment').addEventListener('click',()=>{if(state.moments.length>=30)return alert('O máximo desta prévia é 30 momentos.');state.moments.push({title:'',description:''});renderMoments();remember();});
  function renderPhotos(){const list=byId('photo-list');list.replaceChildren();photoObjects.forEach((p,i)=>{const image=document.createElement('img');image.src=p.url;image.alt='Fotografia adicionada '+(i+1);list.append(image);});}
  byId('photos').addEventListener('change',e=>{
    const files=[...e.target.files];const maxPhotos=state.plan==='premium'?30:10;
    let skipped=0;
    for(const file of files){
      if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>8*1024*1024||file.size===0||photoObjects.length>=maxPhotos){skipped++;continue;}
      photoObjects.push({url:URL.createObjectURL(file),name:file.name});
    }
    renderPhotos();e.target.value='';
    if(skipped)alert(skipped+' arquivo(s) ignorado(s): formato, tamanho ou limite do plano.');
  });
  function renderSummary(){
    const s=byId('summary');s.replaceChildren();
    const rows=[['Capa',(state.name1.trim()||'Você')+' & '+(state.name2.trim()||'seu amor')],['História',state.how.trim()?'Preenchida':'Ainda sem texto'],['Memórias',state.moments.length+' momento(s)'],['Fotos',photoObjects.length+' nesta sessão'],['Estilo',state.style==='natal'?'Noite de Natal':state.style==='cartas'?'Cartas de Amor':'Nosso Filme'],['Plano',state.plan==='premium'?'Premium — R$ 49,90':'Essencial — R$ 29,90']];
    for(const [key,value] of rows){const row=document.createElement('div');const b=document.createElement('b');b.textContent=key+': ';row.append(b,document.createTextNode(value));s.append(row);}
  }
  function prepareStory(data){
    byId('story-view').dataset.style=data.style||'natal';
    const a=data.name1?.trim()||'Você';const b=data.name2?.trim()||'Seu amor';const names=a+' & '+b;
    byId('book-names').textContent=names;byId('story-intro').textContent='Esta é uma história de '+a+' e '+b+'. E, como as histórias mais bonitas, foi feita de pequenos encontros, lembranças e escolhas.';
    byId('story-how').textContent=data.how||'A história de vocês começa aqui. Escreva como se conheceram para ver este capítulo ganhar vida.';
    byId('story-date').textContent=data.date?formatDate(data.date):'NOSSO PRIMEIRO CAPÍTULO';
    byId('story-letter').textContent=data.letter||'Ainda há tantas coisas que quero viver com você. Que nossa história continue sendo nosso lugar favorito.';
    byId('story-signature').textContent='Com amor, '+a;byId('ending-names').textContent=names+' · 2026';
    const timeline=byId('story-timeline');timeline.replaceChildren();
    const moments=data.moments?.length?data.moments:[{title:'Nossa primeira memória',description:'As pequenas histórias se tornam grandes lembranças.'}];
    moments.forEach(m=>{const div=document.createElement('div');div.className='timeline-item';const h=document.createElement('h3');h.textContent=m.title||'Um momento inesquecível';const p=document.createElement('p');p.textContent=m.description||'Uma lembrança que merece ficar aqui.';div.append(h,p);timeline.append(div);});
    const gallery=byId('story-gallery');gallery.replaceChildren();
    if(!currentStoryIsDemo&&photoObjects.length){for(const p of photoObjects){const image=document.createElement('img');image.src=p.url;image.alt='Fotografia do álbum, '+p.name;gallery.append(image);}byId('story-main-image').src=photoObjects[0].url;byId('story-main-image').alt='Primeira fotografia enviada para a prévia';}
    else {byId('story-main-image').src='./assets/memory-couple.svg';byId('story-main-image').alt='Ilustração fictícia de um casal, usada como exemplo';}
    byId('sound').hidden=data.wantsMusic===false;byId('story-chapters').hidden=true;byId('story-open').hidden=false;byId('letter-paper').hidden=true;byId('unseal').hidden=false;byId('unseal').setAttribute('aria-expanded','false');
  }
  function formatDate(raw){const parts=raw.split('-').map(Number);if(parts.length!==3||!parts[0]||!parts[1]||!parts[2])return '';return new Date(Date.UTC(parts[0],parts[1]-1,parts[2])).toLocaleDateString('pt-BR',{timeZone:'UTC',day:'numeric',month:'long',year:'numeric'}).toUpperCase();}
  byId('preview-story').addEventListener('click',()=>{currentStoryIsDemo=false;originScreen='editor';prepareStory(state);go('story');});
  byId('story-back').addEventListener('click',()=>go(originScreen==='editor'?'editor':'landing'));
  byId('open-book').addEventListener('click',()=>{
    const cover=byId('story-open');const button=byId('open-book');
    button.disabled=true;cover.classList.add('opening');
    const finish=()=>{cover.classList.remove('opening');cover.hidden=true;byId('story-chapters').hidden=false;window.scrollTo({top:0,behavior:'instant'});button.disabled=false;};
    if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)finish();else setTimeout(finish,850);
  });
  byId('unseal').addEventListener('click',()=>{byId('letter-paper').hidden=false;byId('unseal').hidden=true;byId('unseal').setAttribute('aria-expanded','true');});
  byId('restart-story').addEventListener('click',()=>{stopMusic();byId('story-chapters').hidden=true;byId('story-open').hidden=false;window.scrollTo({top:0,behavior:'smooth'});});
  function stopMusic(){if(music){music.pause();music.currentTime=0;}byId('sound').textContent='♫ Ouvir trilha';byId('sound').setAttribute('aria-pressed','false');}
  byId('sound').addEventListener('click',async()=>{
    if(!music){music=new Audio('./assets/trilha-original.mp3');music.loop=true;music.volume=.35;}
    if(!music.paused){stopMusic();return;}
    try{await music.play();byId('sound').textContent='Ⅱ Pausar trilha';byId('sound').setAttribute('aria-pressed','true');}catch{byId('sound').textContent='♫ Áudio indisponível';}
  });
  if(!state.moments.length){state.moments.push({title:'',description:''});}
  if('IntersectionObserver' in window){
    const observer=new IntersectionObserver((entries)=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('in-view');observer.unobserve(entry.target);}}),{threshold:.10});
    all('.story-chapters .chapter').forEach(el=>observer.observe(el));
  }
  fillForm();
  const requestedView = new URLSearchParams(window.location.search).get('view');
  if(requestedView === 'editor') go('editor');
  if(requestedView === 'demo'){ currentStoryIsDemo=true;originScreen='landing';prepareStory(demo);go('story'); }
})();
